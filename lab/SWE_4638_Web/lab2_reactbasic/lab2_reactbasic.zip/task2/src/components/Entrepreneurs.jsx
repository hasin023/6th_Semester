const Entrepreneurs = () => {
  return (
    <section className='banner'>
      <h5>
        <span>To help entrepreneurs get their act together</span> before they
        talk to investors.
      </h5>
    </section>
  )
}

export default Entrepreneurs
