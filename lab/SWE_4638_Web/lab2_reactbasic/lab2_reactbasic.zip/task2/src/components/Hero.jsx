const HeroSection = () => {
  return (
    <div className='consulting-rev'>
      <h1>video slider</h1>
      <p>Challenging established thinking, achieving sustainable advantage</p>
      <a href='#'>
        our services
        <i className='fa fa-chevron-right'></i>
      </a>
    </div>
  )
}

export default HeroSection
