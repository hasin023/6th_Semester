import TaskTracker from "./components/TaskTracker";

function App() {
  return <TaskTracker />;
}

export default App;
