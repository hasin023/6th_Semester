const tasks = [
  { id: 1, title: "Learn React basics", completed: false },
  { id: 2, title: "Practice useState hook", completed: true },
  { id: 3, title: "Build first React app", completed: false },
  { id: 4, title: "Build first React app 2", completed: false },
];

export default tasks;
